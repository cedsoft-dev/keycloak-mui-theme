
import { kcMessages } from "keycloakify/lib/i18n/useKcMessage";

Object.assign(
    kcMessages["de"],
    {
        "continueWith": "Weiter mit",
    }
);

Object.assign(
    kcMessages["en"],
    {
        "continueWith": "Continue with",
    }
);