"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
exports.AccountServiceContext = React.createContext(undefined);
//# sourceMappingURL=AccountServiceContext.jsx.map