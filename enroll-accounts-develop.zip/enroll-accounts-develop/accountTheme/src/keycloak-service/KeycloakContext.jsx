"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
exports.KeycloakContext = React.createContext(undefined);
//# sourceMappingURL=KeycloakContext.jsx.map